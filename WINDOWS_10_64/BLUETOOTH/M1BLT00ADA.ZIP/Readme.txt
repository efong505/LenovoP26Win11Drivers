﻿                                                  Revision : 02
--------------------------------------------------------------------------------
Software name      Intel Bluetooth Driver


Supported Operating System：

Windows 10 RS5
Windows 10 20H1
Windows 10 20H2
Windows 10 21H1
Windows 11 SV1
Windows 11 22H2 SV2
Windows 11 MayCI
                 
 


DriverVer = 07/11/2023,22.250.0.2


Module Supported:
Intel AX411
Intel AX211
Intel AX210
Intel AX200
Intel AX201
Intel AX203
Intel AX101
Intel 9560
intel 9462
Intel 9260
Intel 3168
intel 7265
intel 17265

------------------------------------------------------------
Intel3165 = STP1
Intel3168 = SDP
Intel8260 = SFP
Intel8265 = WSP
Intel9462 = JFP1
Intel9260 = THP
Intel9560 = JFP2
IntelAX200 = CCP
IntelAX201 = HRP2
IntelAX203 = JNP(HRP)
IntelAX210 = TYP2
IntelAX211 = GFP2
IntelAX411 = GFP4

--------------------------------------------------------------------------------
CHANGES IN THIS RELEASE
  Version  22.250.0.2

[Problem Fixed]
1. LMP response Timeout and Connection Timeout issues are observed in some specific phone to pc 
	connectivity applications. [AX211 - Raptor Lake]
2. With some Bluetooth Classic mice used in conjunction with Bluetooth earphones (multi profile use case) 
	streaming online music - the mouse pointer is observed to drift randomly. 
	Issue is observed typically when connected to a 2.4Ghz Wi-Fi network as against 5 Ghz network.[AX201-ADL-Lake]
3. In some scenarios, connection to BTOE (Bluetooth Other End device) may fail.[AX201-TGL-Lake]
4. Microphone not functional with specific Philips* headsets (TAH4205XTWT)[AX203-RPL-Lake]

[New Feature]
1. Optimizations for Intel Unison application [AX411 AX211 AX210]
2. Default Enablement of LE 2M PHY upon initiation of LE connection. [AX411 AX211 AX210]

--------------------------------------------------------------------------------
DETERMINING WHICH VERSION IS INSTALLED

  1. Hold down the Windows logo key and press X to open a menu at the lower-left
     area of the screen.
  2. Select Device Manager from the menu.
  3. Double-click the Bluetooth device
  4. Check Driver Version.


--------------------------------------------------------------------------------
NOTES

  Nothing.


--------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS

Note:
- If your computer runs satisfactorily now, it may not be necessary to update
  the software. To determine if you should update the software, refer to the
  Version Information section.


Driver Installation
Manual: Enter into driver package -> double click DriverSetup.exe -> follow the reference

Update: Enter Device Manager -> Right click Bluetooth device -> Update Driver Software... -> Select Browse my computer for driver software -> Select the driver inf file in "driver" folder of the package -> Done

Intel3165 = STP1
Intel3168 = SDP
Intel8260 = SFP
Intel8265 = WSP
Intel9462 = JFP1
Intel9260 = THP
Intel9560 = JFP2
IntelAX200 = CCP
IntelAX201 = HRP
IntelAX203 = JFP
IntelAX210 = TYP
IntelAX211 = GFP2


Silence Install: DriverSetup.exe /VERYSILENT

Driver Uninstallation
- Windows 10
Device manager uninstall: Enter Device Manager -> Expand related device then Right click and Select "Uninstall device" ->Select the box for "Delete the driver software for this device" and Click "Uninstall" -> Wait a moment-> Reboot the system -> Done
- Windows 11
Device manager uninstall: Enter Device Manager -> Expand related device then Right click and Select "Uninstall device" ->Select the box for "Attempt to remove the driver for this device" and Click "Uninstall" -> Wait a moment-> Reboot the system -> Done

Control Panel uninstall: Not support

--------------------------------------------------------------------------------
VERSION INFORMATION


  Version         Build ID        Rev.     Issue Date
  ----------      --------       ----     ----------
  xxxxx            xxxx           02        xxxxx

  Note: Revision number (Rev.) is for administrative purpose of this README
        document and is not related to software version. There is no need to
        upgrade this software when the revision number changes.

  To check the version of software, refer to the Determining which version is
  installed section.

--------------------------------------------------------------------------------
LIMITATIONS

  Nothing.


--------------------------------------------------------------------------------
TRADEMARKS

* Lenovo and IdeaCentre are registered trademarks of Lenovo.

* Intel is a registered trademark of Intel Corporation.
* Microsoft, Internet Explorer and Windows are registered trademarks of
  Microsoft Corporation.

Other company, product, and service names may be registered trademarks,
trademarks or service marks of others.
