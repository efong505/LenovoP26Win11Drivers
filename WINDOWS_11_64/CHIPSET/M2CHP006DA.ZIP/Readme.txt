﻿                                                  Revision : 01
--------------------------------------------------------------------------------
Software name      AMD Chipset Driver 
5.05.12.126-IO-12052023
  
AMD PCI Device Driver   	Windows 11(64-bit)	1.0.0.90
AMD I2C Driver	            Windows 11(64-bit)	1.2.0.121
AMD UART Driver	            Windows 11(64-bit)	1.2.0.114
AMD GPIO2 Driver	        Windows 11(64-bit)	2.2.0.130
PT GPIO Driver	            Windows 11(64-bit)	3.0.0.0
AMD PSP Driver	            Windows 11(64-bit)	5.23.0.0
AMD IOV Driver	            Windows 11(64-bit)	1.2.0.52
AMD SMBUS Driver	        Windows 11(64-bit)	5.12.0.38

               
Operating Systems  
 Windows 11




--------------------------------------------------------------------------------
CHANGES IN THIS RELEASE
5.05.12.126-IO-12052023

[Problem fixed]
 Nothing


--------------------------------------------------------------------------------
DETERMINING WHICH VERSION IS INSTALLED

  1. Hold down the Windows logo key and press X to open a menu at the lower-left
     area of the screen.
  2. Select Device Manager from the menu.
  3. Double-click the devices in System Devices category.such as :AMD PCI.
  4. Check Driver Version.


--------------------------------------------------------------------------------
NOTES

  Nothing.


--------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS

Note:
- If your computer runs satisfactorily now, it may not be necessary to update
  the software. To determine if you should update the software, refer to the
  Version Information section.


Driver Installation
Manual: Enter into driver package -> double click DriverSetup.exe -> follow the reference

Update: Enter Device Manager -> Right click related device -> Update Driver Software -> Select Browse my computer for driver software -> Select the driver inf file in "driver" folder of the package -> Done

Silence Install: DriverSetup.exe /VERYSILENT

Driver Uninstallation
- Windows 11
Device manager uninstall: Enter Device Manager -> Expand related device then Right click and Select "Uninstall device" ->Select the box for "Attempt to remove the driver for this device" and Click "Uninstall" -> Wait a moment-> Reboot the system -> Done

Control Panel uninstall: Not support

--------------------------------------------------------------------------------
VERSION INFORMATION


  Version            Build ID       Rev.     Issue Date
  ----------         --------       ----     ----------
  xxxxxx              xxxxxx        02        xxxxxxx


  Note: Revision number (Rev.) is for administrative purpose of this README
        document and is not related to software version. There is no need to
        upgrade this software when the revision number changes.

  To check the version of software, refer to the Determining which version is
  installed section.

--------------------------------------------------------------------------------
LIMITATIONS

  Nothing.


--------------------------------------------------------------------------------
TRADEMARKS

* Lenovo and IdeaCentre are registered trademarks of Lenovo.

* AMD is a registered trademark of Advanced Micro Devices, Inc.
* Microsoft, Internet Explorer and Windows are registered trademarks of
  Microsoft Corporation.

Other company, product, and service names may be registered trademarks,
trademarks or service marks of others.
