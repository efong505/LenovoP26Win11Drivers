﻿                                   Revision : 01
--------------------------------------------------------------------------------
Software name      Broadcom LAN Driver
                 
Operating Systems  Microsoft Windows 10 64-bit/Microsoft Windows 11 64-bit

Driver version	221.0.5.0

--------------------------------------------------------------------------------
WHAT THIS PACKAGE DOES

  This package installs the software to enable the following device.
  
  Broadcom 5720 2-Ports Ethernet Adapter
  Broadcom 5719 4-Ports Ethernet Adapter

 
  Device name in the Device Manager
  ---------------------------------
  Broadcom Netxtreme Gigabit Ethernet. 

  Refer to marketing materials to find out what computer models support which
  devices.

  This program is language independent and can be used with any language system.

--------------------------------------------------------------------------------
CHANGES IN THIS RELEASE

[Problem fixes]
  -Nothing.

[Support Scope]
--------------------------------------------------------------------------------
DETERMINING WHICH VERSION IS INSTALLED

  1. Hold down the Windows logo key and press X to open a menu at the lower-left
     area of the screen.
  2. Select Device Manager from the menu.
  3. Double-click the Network adapters category.
  4. Double-click one of the following devices depending on product type.
  5. Select the Driver tab.
  6. Check Driver Version.


--------------------------------------------------------------------------------
NOTES

  Nothing.


--------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS

Note:
- If your computer runs satisfactorily now, it may not be necessary to update
  the software. To determine if you should update the software, refer to the
  Version Information section.


Manual Install

  1. Make sure to be logged on with an administrator account.
  2. Locate the folder where the file was downloaded.
  3. Locate the file that was downloaded and double-click/double-tap "Setup".
  4. Follow the instructions on the screen.
  5. In the Ready to Finish window, select "Install setup now". 

     IMPORTANT: Make sure to restart the computer after installation.

Unattended Install

  1. At the command line, execute Setup.exe /VERYSILENT option.


--------------------------------------------------------------------------------

UNINSTALLATION INSTRUCTIONS

Manual Uninstall

 [Windows 10]
  1. Entry Device Manager
  2. Select Broadcom Neworking Device, Right Click.
  3. Select Uninstall device, check "Delete the driver software for this device",Click Uninstall"

--------------------------------------------------------------------------------

INF Installation
  1. On Windows 10\Windows 11: Press Windows key and X.
  2. Click on the "Device Manager" link in the column on the left side of the window.
  3. Select "Device Manager" from the menu, then find "Network adapters".
  4. Right Click on " Broadcom NetXtreme Gigabit Ethernet", then select "Update driver".
  5. Then follow the following prompt.
--------------------------------------------------------------------------------
LIMITATIONS
N/A


--------------------------------------------------------------------------------
TRADEMARKS

* Lenovo and IdeaCentre are registered trademarks of Lenovo.
* Microsoft, Internet Explorer and Windows are registered trademarks of
  Microsoft Corporation.

Other company, product, and service names may be registered trademarks,
trademarks or service marks of others.
