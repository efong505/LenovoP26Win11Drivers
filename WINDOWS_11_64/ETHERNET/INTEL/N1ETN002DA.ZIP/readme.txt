﻿                                   Revision : 01
--------------------------------------------------------------------------------
Software name      Intel(R) LAN Driver
                 
Operating Systems  Microsoft Windows 11 64-bit

Intel package Version  27.1
Intel Proset:27.1

Driver version
I210/350:	 13.0.13.0
X540/X550: 4.1.219.0
X710: 1.16.139.0

--------------------------------------------------------------------------------
WHAT THIS PACKAGE DOES

  This package installs the software to enable the following device.

  Device name in the Device Manager
  ---------------------------------
  Intel(R) I210 Gigabit Network Connection
  Intel(R) Ethernet Server Adapter I210-T1
  Intel(R) Ethernet Server Adapter I350-T2
  Intel(R) Ethernet Server Adapter I350-T4
  Intel(R) Ethernet Converged Network Adapter X540-T2
  Intel(R) Ethernet Converged Network Adapter X550-T2
  Intel(R) Ethernet Converged Network Adapter X710  

  Refer to marketing materials to find out what computer models support which
  devices.

  This program is language independent and can be used with any language system.

--------------------------------------------------------------------------------
CHANGES IN THIS RELEASE

27.1


[Problem fixes]
  -Nothing.


--------------------------------------------------------------------------------
DETERMINING WHICH VERSION IS INSTALLED

  1. Hold down the Windows logo key and press X to open a menu at the lower-left
     area of the screen.
  2. Select Device Manager from the menu.
  3. Double-click the Network adapters category.
  4. Double-click one of the following devices depending on product type.
  5. Select the Driver tab.
  6. Check Driver Version.


--------------------------------------------------------------------------------
NOTES

  Nothing.


--------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS

Note:
- If your computer runs satisfactorily now, it may not be necessary to update
  the software. To determine if you should update the software, refer to the
  Version Information section.


Manual Install

  1. Make sure to be logged on with an administrator account.
  2. Locate the folder where the file was downloaded.
  3. Locate the file that was downloaded and double-click/double-tap "Setup".
  4. Follow the instructions on the screen.
  5. In the Ready to Finish window, select "Install setup now". 

     IMPORTANT: Make sure to restart the computer after installation.

Unattended Install

  1. At the command line, execute Setup.exe /VERYSILENT option.


--------------------------------------------------------------------------------

UNINSTALLATION INSTRUCTIONS

Manual Uninstall

 [Windows 11]
  1. Entry Device Manager
  2. Select Intel Networking Device, Right Click.
  3. Select Uninstall Device, check "Attempt to remove the driver for this device".
     Then select "Uninstall".


--------------------------------------------------------------------------------
VERSION INFORMATION

  The following versions have been released to date.

  Version              Build ID            Rev.     Issue Date
  ----------------     --------------      ----     ----------
  NA                   NA                  NA       NA

   
  Note: Revision number (Rev.) is for administrative purpose of this README
        document and is not related to software version. There is no need to
        upgrade this software when the revision number changes.

  To check the version of software, refer to the Determining which version is
  installed section.

--------------------------------------------------------------------------------
LIMITATIONS

This package not inculde Intel PROSet APP, not support advanced network service, so not support teaming and vlan.
If you need this APP, please download driver pack from Intel web site(https://downloadcenter.intel.com/product/36773/Ethernet-Products)


--------------------------------------------------------------------------------
TRADEMARKS

* Lenovo and IdeaCentre are registered trademarks of Lenovo.

* Intel is a registered trademark of Intel Corporation.
* Microsoft, Internet Explorer and Windows are registered trademarks of
  Microsoft Corporation.

Other company, product, and service names may be registered trademarks,
trademarks or service marks of others.
