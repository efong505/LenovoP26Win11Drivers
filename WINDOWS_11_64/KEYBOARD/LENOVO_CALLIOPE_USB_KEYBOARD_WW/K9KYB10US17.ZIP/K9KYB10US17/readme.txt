Lenovo Calliope USB Keyboard - Readme Instructions

Latest driver version: 1.14

I. SYSTEM REQUIREMENTS

Software:
 Windows 7/8.1/10/11

Hardware:
A computer PC with USB ports.
At least 800*600 display resolution.


II. INSTALLATION INSTRUCTIONS

To install the software for your Lenovo Calliope USB Keyboard,
please follow below steps:

1. Turn your system on and start Windows.
2. Connect your Lenovo Calliope USB Keyboard to the USB port of your PC.
3. If this is the first that you connect the Lenovo Calliope USB Keyboard 
   to your system, some "New Device Found" messages may appear on the 
   screen. Follow the onscreen instructions to complete the installation.
4. Run the setup program within this package to install the software for
   your Lenovo Calliope USB Keyboard. There is a argument switch for the
   setup program:
	setup.exe /s /v/qn	silent installation, no user input needed


III. UNINSTALLATION INSTRUCTIONS

To remove this software, please follow below steps:

1. Open the Control Panel by clicking Settings from Start Menu.
2. Open the "Programs and Feature", and select "Lenovo Calliope USB Keyboard" from the list.
   Click on the "Uninstall" button, and follow the instructions to complete uninstallation.

Reminding:
1. Setting button(Fn+F9) is not available under Windows 7.