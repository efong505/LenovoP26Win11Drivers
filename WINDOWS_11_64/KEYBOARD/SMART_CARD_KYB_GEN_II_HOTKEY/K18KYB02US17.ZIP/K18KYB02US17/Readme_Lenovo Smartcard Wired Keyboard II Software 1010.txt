Lenovo Smartcard Wired Keyboard II Software for Windows7/Win10/Win11



Software Version 
==============
    Windows11: 1.0.1.0
    Windows10: 1.0.1.0
    Windows7:   1.0.1.0

Smartcard Driver Version
==============
    Windows11: 2.5.0.4
    Windows10: 2.5.0.0
    Windows7:   2.2.0.1


CONTENTS
========
    1. Installation Guide
    2. Uninstallation Guide
    3. Changes
    4. Version History



1. Installation Guide
=====================
    -- Normal installation:
       Running the exe file directly you download to install this driver/software.

    -- Silent installation:
       Please download the exe file to the path you assigned, then go to the given path and use the below command for the setup program:
       setup.exe /VERYSILENT  for silent installation, no user input needed
           


2. Uninstallation Guide
=======================
    -- Normal uninstallation:   
       1.In Control Panel, open "Programs and Features" in Win7/ Win10/ Win11.

       2. In Install/Uninstall tab, select this software from the list and click on the "Add/Remove" or "Uninstall/Change" button.

       3. Follow the instruction on the screen to complete the uninstallation procedure.
	 
    -- Silent uninstallation:
        Run below command for uninstall program:
        "C:\Program Files (x86)\Lenovo Smartcard Wired Keyboard II Software\unins000.exe" /VERYSILENT    
　　 


3. Changes
==========
    1.0.1.0 (Fixed:Add signature to file dpinst.exe and uninstall.exe）
    1.0.0.9 (Fixed: Add signature to file NAudio.dll)
    1.0.0.8 (Fixed: "Allow this device to wake the computer out of standby" cannot be checked for hot swappable keyboard)
    1.0.0.7 (Fixed: Smartcard Driver compatible with windows 11)
    1.0.0.6 (Fixed: icon problem and optimize)
    1.0.0.5 (Fixed: icon problem and optimize)
    1.0.0.4 (Fixed: FW update)
    1.0.0.3 (Fixed: Smartcard Driver update)
    1.0.0.2 (Fixed: 1. Software change ico; 2. Multi-language processing;) 
    1.0.0.1 (Fixed: 1. Mic mute and ThinkPad OSD conflict correction;  2. FW update;  3. F10 screenshot tool;) 
    1.0.0.0 (First release)



4. Version History
==========================
    1.0.1.0 (Date:2023/04/20)
    1.0.0.9 (Date: 2023/04/13)
    1.0.0.8 (Date: 2022/12/05)
    1.0.0.7 (Date: 2021/12/24)
    1.0.0.6 (Date: 2021/03/29)
    1.0.0.5 (Date: 2021/03/22)
    1.0.0.4 (Date: 2021/03/08)
    1.0.0.3 (Date: 2021/01/29)
    1.0.0.2 (Date: 2020/12/23)
    1.0.0.1 (Date: 2020/11/26)
    1.0.0.0 (Date: 2020/11/12)
