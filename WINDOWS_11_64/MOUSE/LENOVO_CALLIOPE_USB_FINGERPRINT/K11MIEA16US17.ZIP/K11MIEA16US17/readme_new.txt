Lenovo Fingerprint Mouse - Readme Instructions

Fingerprint driver version: 5.5.2339.1061

(c) Copyright Synaptics, All Rights Reserved.


I. SYSTEM REQUIREMENTS

Software:
Windows XP, Windows Vista, Windows 7, Windows 8, Windows 8.1, Windows 10,Windows 11

Hardware:
A computer PC with USB ports.


II. INSTALLATION INSTRUCTIONS

To install the software for your Lenovo Fingerprint Mouse, please follow below steps:

1. Attach Lenovo Fingerprint sensor Mouse(PID:0089) to the system 
2. Right click "this PC" and click "Manager" to launch Device Manager
3. Right click Unknown device(PID:0089) and then click update driver
4. Click "Browse my computer for drivers" and select the right driver folder and click next
5. After driver installation was completed.The Unknown device name will change to "Synaptics WBDI Fingerprint Reader 061" in Biometric devices. 
6. Driver install successfully. 

 SILENT INSTALL

Setup.exe is located in the following folders:
<Drive>\

Silent install:
1. Open CMD command Window as Administer
2. Input "DriverSetup.exe /VERYSILENT" 
 



III. UNINSTALLATION INSTRUCTIONS

To remove this software, please follow below steps:

1. In Device Manager, choose Biometric devices(Vista & Win 7 & Win 8 & Win8.1 & Win10&win11)
2. Right click "Synaptics WBDI Fingerprint Reader 061" and Click "Uninstall device" left Click "Uninstall"
3. Check "Delete the driver softwre for this divice" item and Click "Uninstall"
4. Click "Scan for hardware changes" then "Unknown device" will show in other devices in device manager.
5. Driver Uninsall successfully.


