﻿                                                  Revision : 02
--------------------------------------------------------------------------------
Version:  11/15/2021,7.720.4.0
  

               
Operating Systems  
 Windows 11


Module Supported：

9540-8i
9560-16i
--------------------------------------------------------------------------------
CHANGES IN THIS RELEASE
Version 7.720.4.0

[Problem fixed]
 Nothing


--------------------------------------------------------------------------------
DETERMINING WHICH VERSION IS INSTALLED

  1. Hold down the Windows logo key and press X to open a menu at the lower-left
     area of the screen.
  2. Select Device Manager from the menu.
  3. Double-click the MegaRAID controller in the Storage Controllers category.such as :MegaRAID 9540-8i
  4. Check Driver Version.


--------------------------------------------------------------------------------
NOTES

  Nothing.


--------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS

Note:
- If your computer runs satisfactorily now, it may not be necessary to update
  the software. To determine if you should update the software, refer to the
  Version Information section.


Driver Installation
Manual: Enter into driver package -> double click DriverSetup.exe -> follow the reference

Update: Enter Device Manager -> Right click related device -> Update Driver Software -> Select Browse my computer for driver software -> Select the driver inf file in "driver/Intel_WIFI" folder of the package -> Done

Silence Install: DriverSetup.exe /VERYSILENT

Driver Uninstallation
Device manager uninstall: Enter Device Manager -> Expand related device then Right click and Select "Uninstall device" ->Select the box for "Delete the driver software for this device" and Click "Uninstall" -> Wait a moment-> Reboot the system -> Done


Control Panel uninstall: Not support

--------------------------------------------------------------------------------
VERSION INFORMATION


  Version            Build ID       Rev.     Issue Date
  ----------         --------       ----     ----------
  xxxxxx              xxxxxx        02        xxxxxxx


  Note: Revision number (Rev.) is for administrative purpose of this README
        document and is not related to software version. There is no need to
        upgrade this software when the revision number changes.

  To check the version of software, refer to the Determining which version is
  installed section.

--------------------------------------------------------------------------------
LIMITATIONS

  Nothing.


--------------------------------------------------------------------------------
TRADEMARKS

* Lenovo and IdeaCentre are registered trademarks of Lenovo.

* Microsoft, Internet Explorer and Windows are registered trademarks of
  Microsoft Corporation.

Other company, product, and service names may be registered trademarks,
trademarks or service marks of others.
